# Notes 1


## What is Markdown?
Markdown is a **markup language** that lets you write plain text documents with a few lightweight formatting options, Created by *John Gruber* in 2004


## What is Git?
 a free, open-source, distributed **version control system** (VCS) that tracks changes to files over time, enabling developers to collaborate on projects, revert to previous versions, and manage different lines of development efficiently.


## What is GitHub?
a cloud-based platform built on Git that allows developers to store, manage, and share code, enabling real-time, collaborative software development and open-source projects


## What is Slack?
downloadable software application for team communication and collaboration, available for desktop (Windows, Mac, Linux) and mobile (Android, iOS) devices.